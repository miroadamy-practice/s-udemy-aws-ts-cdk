import React from "react";



export class Home extends React.Component {


    render(){
        return(
            <div>
                Welcome to the Home page!
            </div>
        )
    }
}