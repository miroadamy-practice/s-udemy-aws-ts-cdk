

export const config = {
    REGION: 'eu-west-1',
    USER_POOL_ID: 'eu-west-1_gRIUoOdLx',
    APP_CLIENT_ID: '335vma5jmludo42mn2895cu5bh',
    TEST_USER_NAME: 'barosanu2',
    TEST_USER_PASSWORD: 'askjskfT7sdf&'
}