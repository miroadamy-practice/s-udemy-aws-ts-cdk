


export interface Space {
    spaceId: string,
    name: string,
    location: string,
    photoUrl?: string
}