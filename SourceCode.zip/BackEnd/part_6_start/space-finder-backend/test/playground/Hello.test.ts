import { handler } from '../../services/node-lambda/hello';


handler({}, {});